# Build Campus Connect APK using only an Android phone

This project includes a GitHub Actions workflow that builds the APK on GitHub's cloud computers. You do not need Android Studio or a laptop.

## Steps
1. Extract this ZIP on your phone.
2. Open https://github.com in Chrome and create/sign in to a GitHub account.
3. Create a **new public repository** named `campus-connect` (public repositories get GitHub Actions minutes on the free plan; do not upload passwords, API keys, or private student data).
4. In the repository, use **Add file → Upload files**. Upload the *contents* of this `CampusConnect` folder, including the hidden `.github` folder. If the phone browser does not show hidden folders or cannot upload folders, switch Chrome to **Desktop site**. The `.github/workflows/build-apk.yml` file is required for the build.
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab. Select **Build Campus Connect APK** if prompted, then open the latest run.
7. Wait for the build to finish successfully. Under **Artifacts**, tap `campus-connect-debug-apk` to download the APK ZIP.
8. Extract that downloaded ZIP. Tap `app-debug.apk` and allow Android to install apps from that source if Android asks. Only install APKs you built from source you trust.

## Notes
- This creates a **debug APK** for testing, not a production/release-signed APK for public distribution.
- This app is currently a UI prototype with sample/local chat data. It does not yet provide real online messaging, real student verification, calls, or push notifications.
- Never put real passwords or private student information in this prototype.
