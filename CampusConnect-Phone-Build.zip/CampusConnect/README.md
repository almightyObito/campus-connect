# Campus Connect — Android starter app

A native Android/Jetpack Compose starter for a UNILESA student community. The registration form intentionally does **not** ask for a matric number.

## Open and build
1. Install Android Studio (current stable) on a computer.
2. Open this `CampusConnect` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK output location (usually `app/build/outputs/apk/debug/app-debug.apk`).

## Important current limitations
This is a front-end prototype. It demonstrates registration UI, navigation, sample chats, group/notice lists, profile and a local-only message composer. It does not yet create real accounts, verify UNILESA membership, sync messages between phones, deliver push notifications, or support real calls/file uploads. Those require a secure backend and student-verification process (for example Firebase Authentication, Firestore, and Storage), plus privacy rules and moderation tools. Do not use real student passwords or sensitive information in this prototype.
