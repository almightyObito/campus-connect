package com.campusconnect.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF087F5B)
private val Ink = Color(0xFF14211D)
private val Muted = Color(0xFF718078)
private val Canvas = Color(0xFFF4F7F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CampusConnectApp() }
    }
}

@Composable
fun CampusConnectApp() {
    var signedIn by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var department by remember { mutableStateOf("") }
    var faculty by remember { mutableStateOf("") }
    var level by remember { mutableStateOf("100 Level") }
    var password by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Chats") }
    var selectedChat by remember { mutableStateOf<String?>(null) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Canvas, surface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Canvas) {
            when {
                !signedIn -> RegisterScreen(name, { name = it }, department, { department = it }, faculty, { faculty = it }, level, { level = it }, password, { password = it }) { signedIn = true }
                selectedChat != null -> ChatScreen(selectedChat!!, onBack = { selectedChat = null })
                else -> MainScreen(tab, { tab = it }, { selectedChat = it }, name.ifBlank { "Student" }, department)
            }
        }
    }
}

@Composable
fun RegisterScreen(name: String, onName: (String) -> Unit, dept: String, onDept: (String) -> Unit,
                   faculty: String, onFaculty: (String) -> Unit, level: String, onLevel: (String) -> Unit,
                   password: String, onPassword: (String) -> Unit, onCreate: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp), verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(62.dp).background(Green, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Groups, null, tint = Color.White, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text("CAMPUS CONNECT", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Text("Your UNILESA campus community", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(26.dp))
        Text("Create your student account", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(name, onName, Modifier.fillMaxWidth(), label = { Text("Full name") }, singleLine = true)
        Spacer(Modifier.height(9.dp))
        OutlinedTextField(dept, onDept, Modifier.fillMaxWidth(), label = { Text("Department") }, singleLine = true)
        Spacer(Modifier.height(9.dp))
        OutlinedTextField(faculty, onFaculty, Modifier.fillMaxWidth(), label = { Text("Faculty") }, singleLine = true)
        Spacer(Modifier.height(9.dp))
        var expanded by remember { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { expanded = true }, Modifier.fillMaxWidth()) {
                Text(level, Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null)
            }
            DropdownMenu(expanded, { expanded = false }) {
                listOf("100 Level", "200 Level", "300 Level", "400 Level", "500 Level").forEach {
                    DropdownMenuItem(text = { Text(it) }, onClick = { onLevel(it); expanded = false })
                }
            }
        }
        Spacer(Modifier.height(9.dp))
        OutlinedTextField(password, onPassword, Modifier.fillMaxWidth(), label = { Text("Create password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
        Spacer(Modifier.height(18.dp))
        Button(onClick = onCreate, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp), enabled = name.isNotBlank() && dept.isNotBlank() && faculty.isNotBlank() && password.length >= 4) {
            Text("Create account", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        Text("For UNILESA students only • Matric number is not required", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun MainScreen(tab: String, onTab: (String) -> Unit, onChat: (String) -> Unit, student: String, department: String) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Green).padding(start = 20.dp, end = 18.dp, top = 22.dp, bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CAMPUS CONNECT", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                Text("UNILESA • Stay connected", color = Color(0xFFD8F2E8), fontSize = 12.sp)
            }
            Icon(Icons.Default.NotificationsNone, null, tint = Color.White, modifier = Modifier.size(26.dp))
        }
        Row(Modifier.fillMaxWidth().background(Color.White), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Chats", "Groups", "Notice", "Profile").forEach { item ->
                Column(Modifier.clickable { onTab(item) }.padding(vertical = 13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(item, color = if (tab == item) Green else Muted, fontWeight = if (tab == item) FontWeight.Bold else FontWeight.Normal)
                    Spacer(Modifier.height(5.dp)); Box(Modifier.width(34.dp).height(3.dp).background(if (tab == item) Green else Color.Transparent, CircleShape))
                }
            }
        }
        when (tab) {
            "Chats" -> {
                Column(Modifier.padding(18.dp)) {
                    Text("Good day, $student 👋", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text(if (department.isBlank()) "Your class conversations" else department, color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField("", {}, Modifier.fillMaxWidth(), placeholder = { Text("Search classmates") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                }
                LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp)) {
                    items(listOf("Class Representative", "Theatre Arts 100L", "Course Discussion", "Study Partners", "Campus Updates")) { title -> ChatRow(title, onClick = { onChat(title) }) }
                }
            }
            "Groups" -> SimpleList("Your course groups", listOf("Theatre Arts • 100 Level", "General Studies", "Class Announcements"), onChat)
            "Notice" -> SimpleList("Campus announcements", listOf("Welcome to Campus Connect", "Keep course discussions respectful", "Check with your department for class updates"), onChat)
            else -> Column(Modifier.padding(22.dp)) {
                Text("Your profile", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.height(18.dp)); ProfileLine("Name", student); ProfileLine("Department", department.ifBlank { "Not added" }); ProfileLine("University", "University of Ilesa"); ProfileLine("Account", "Student")
            }
        }
        Spacer(Modifier.weight(1f))
        Text("Connect • Learn • Grow", Modifier.fillMaxWidth().background(Color.White).padding(13.dp), color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun ChatRow(title: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).background(Color(0xFFE0F2EA), CircleShape), contentAlignment = Alignment.Center) { Text(title.take(1).uppercase(), color = Green, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text("Tap to open conversation", color = Muted, fontSize = 12.sp)
        }
        Text("›", color = Muted, fontSize = 26.sp)
    }
    HorizontalDivider(color = Color(0xFFE9EEEB))
}

@Composable
fun SimpleList(heading: String, items: List<String>, onChat: (String) -> Unit) {
    Column(Modifier.padding(18.dp)) {
        Text(heading, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(12.dp))
        items.forEach { ChatRow(it) { onChat(it) } }
    }
}

@Composable
fun ProfileLine(label: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 9.dp)) {
        Text(label, color = Muted, fontSize = 12.sp); Text(value, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        HorizontalDivider(Modifier.padding(top = 10.dp), color = Color(0xFFE9EEEB))
    }
}

@Composable
fun ChatScreen(title: String, onBack: () -> Unit) {
    var message by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf("Welcome to $title!", "Use this space to discuss classes and assignments.") }
    Column(Modifier.fillMaxSize().background(Color(0xFFEFF5F1))) {
        Row(Modifier.fillMaxWidth().background(Green).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.ArrowBack, null, tint = Color.White, modifier = Modifier.clickable { onBack() })
            Text(title, Modifier.padding(start = 18.dp), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Text(msg, Modifier.widthIn(max = 290.dp).background(Color(0xFFD8F5E5), RoundedCornerShape(14.dp)).padding(12.dp), color = Ink)
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color.White).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(message, { message = it }, Modifier.weight(1f), placeholder = { Text("Message") }, shape = RoundedCornerShape(24.dp), singleLine = true)
            IconButton(onClick = { if (message.isNotBlank()) { messages.add(message.trim()); message = "" } }) {
                Icon(Icons.Default.Send, "Send message", tint = Green)
            }
        }
    }
}
